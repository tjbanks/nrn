/* src/nrnpython/nrnpython_config.h.  Generated from nrnpython_config.h.in by configure.  */
#ifndef H_nrnpython_config_included
#define H_nrnpython_config_included 1
/* Define if Python available */
#define USE_PYTHON 1
/* Define if dynamic loading desired */
/* #undef NRNPYTHON_DYNAMICLOAD */

#ifndef NRNHOSTCPU
/* Define to the nrnivmodl consistent cpu name */
#define NRNHOSTCPU "x86_64"
#endif

#endif /* H_nrnpython_config_included */

