/* src/oc/nrnpthread.h.  Generated from nrnpthread.h.in by configure.  */
#ifndef nrnpthread_h
#define nrnpthread_h

/* Configure with use_pthread=no if pthread.h exists but you do not want to use it */
#define USE_PTHREAD 1

#endif
