/* src/oc/nrnrtuse.h.  Generated from nrnrtuse.h.in by configure.  */
#ifndef usenrnrt_h
#define usenrnrt_h

/* define if want to use as rtlinux dynamic clamp */
/* #undef NRN_REALTIME */

/* define if have a NI PCI-6229 DAQ board */
/* #undef NRN_6229 */

#endif
