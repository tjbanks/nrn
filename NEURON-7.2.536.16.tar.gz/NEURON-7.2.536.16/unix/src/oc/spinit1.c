#include <../../nrnconf.h>
hoc_last_init() {} /* called at end of hoc_spinit in hocusr.c */

