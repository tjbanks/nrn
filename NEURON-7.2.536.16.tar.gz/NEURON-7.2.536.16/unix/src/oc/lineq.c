#include <../../nrnconf.h>
/*
 * Automake doesn't deal well with sources that live in other directories, so
 * this is a quick and dirty workaround.
 */
#include "../sparse/lineq.c"
