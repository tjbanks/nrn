#include <../../nrnconf.h>
modl_reg(){} /* dummy modl registration: see hocusr.c */

