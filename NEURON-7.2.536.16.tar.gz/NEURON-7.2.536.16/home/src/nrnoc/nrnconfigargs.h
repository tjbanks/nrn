/* src/nrnoc/nrnconfigargs.h.  Generated from nrnconfigargs.h.in by configure.  */
#ifndef nrnconfigargs_h
#define nrnconfigargs_h

/* define to the args passed to configure */
#define NRN_CONFIG_ARGS " '--prefix=/home/hines/neuron/nrnalphasetup' '--with-paranrn' '--with-nrnpython'"

#endif
